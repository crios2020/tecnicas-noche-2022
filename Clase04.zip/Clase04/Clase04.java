public class Clase04 {
    public static void main(String[] args) {
        System.out.println("Clase 04");

        boolean log1 = true;
        boolean log2 = false;
        int nro1 = 10;
        int nro2 = 20;

        System.out.println(
                !log1 || !!log2 || nro1 + 5 != nro2 - 5 || (!!!log2 && nro1 + 2 < nro2 - 3 && nro1 * 2 == nro2));

        // Estructura condicional IF
        if (log1) {
            System.out.println("Verdad 1");
            // código esta indentado
        }

        if (log1 == true) {
            System.out.println("Verdad 2");
        }

        if (nro1 == nro2) {
            System.out.println("Verdad 3");
            System.out.println("Verdad 3");
        }

        // Uso de llaves {}
        // Modo abreviado
        if(log1) System.out.println("Verdad 4");
        
        
        // Modo expandido - Recomendado por Microsoft
        if(log1)
        {
            System.out.println("Verdad 5");
        }
        
        System.out.println("Fin del programa");

        //Estructura condicional IF - ELSE
        if(log1){
            System.out.println("Verdad 6");
        }else{
            System.out.println("Falso 6");
        }

        //Modo Abreviado
        if(log1)    System.out.println("Verdad 7");
        else        System.out.println("Falso7");

        //Modo Expandido
        if(log1)
        {
            System.out.println("Verdad 8");
        }
        else
        {
            System.out.println("Falso 8");
        }

        //Ejemplo de uso de colores
        System.out.println(Colores.ANSI_RED+"Hola a todos!"+Colores.ANSI_RESET);


    }
}