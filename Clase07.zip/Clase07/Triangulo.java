import java.util.Scanner;

public class Triangulo {
    public static void main(String[] args) {
        System.out.println("Ingresar longitud de la base:");
        double base=new Scanner(System.in).nextInt();
        System.out.println("Ingresar longitud de la altura:");
        double altura=new Scanner(System.in).nextInt();

        double superficie=base*altura/2*100;
        double perimetro=   Math.round(
                                Math.sqrt(Math.pow(base, 2)+
                                Math.pow(altura, 2))+base+altura
                            );
        System.out.println("Superficie: "+superficie);
        System.out.println("Perimetro: "+perimetro);

        
    }
}
