import java.util.Scanner;

public class Login {
    
    public static void main(String[] args) {
        System.out.println(Colores.ANSI_GREEN);
        System.out.println("****************************************");
        System.out.println("*          Ingreso al Sistema          *");
        System.out.println("****************************************");
        System.out.println();

        //para compilar javac *.java
        //para ejecutar java Login
        //para ejecutar java Login root 123

        String usuario;
        String clave;
        if(args.length==2){
            usuario=args[0];
            clave=args[1];
        }else{
            System.out.print("Ingrese su nombre de Usuario: ");
            usuario=new Scanner(System.in).nextLine();
            System.out.print("Ingrese su clave: ");
            clave=new Scanner(System.in).nextLine();
        }
        if(usuario.equals("root") && clave.equals("123")) 
            System.out.println(Colores.ANSI_BLUE+"Bienvenido al sistema!");
        if(usuario.equals("root") && !clave.equals("123"))  
            System.out.println(Colores.ANSI_RED+"Clave Incorrecta!");  
        if(!usuario.equals("root")) 
            System.out.println(Colores.ANSI_RED+"Usuario Incorrecto!");
        
        System.out.println(Colores.ANSI_RESET);
    }
}
