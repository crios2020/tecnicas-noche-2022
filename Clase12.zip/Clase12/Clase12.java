public class Clase12{
    public static void main(String[] args) {
        // Arrays - Vectores
        
        //declaración de vector
        int[] numeros=new int[4];
        String[] nombres=new String[4];

        numeros[0]=1;
        nombres[0]="Juan";
        numeros[1]=2;
        nombres[1]="Ana";
        numeros[2]=3;
        nombres[2]="Javier";
        numeros[3]=4;
        nombres[3]="Maria";
        //numeros[4]=5;             //error fuera de rango
        //nombres[4]="Karina";      //error fuera de rango

        //La primer posición de un vector tiene indice 0
        //La ultima posición tiene indice N-1

        /*
         *      numeros     nombres         indice
         *          1       Juan                0
         *          2       Ana                 1
         *          3       Javier              2
         *          4       Maria               3
         */

        System.out.println(numeros[2]+" "+nombres[2]);
        //recorrido del vector
        System.out.println("***********************");
        for(int a=0; a<4; a++) System.out.println(numeros[a]+" "+nombres[a]);

        //metodo length
        System.out.println("Longitud números: "+numeros.length);

        //recorrido usando método length
        System.out.println("***********************");
        for(int a=0; a<numeros.length; a++) 
            System.out.println(numeros[a]+" "+nombres[a]);
        
        //recorrido usando while
        System.out.println("***********************");
        int x=0;
        while(x<numeros.length){
            System.out.println(numeros[x]+" "+nombres[x]);
            x++;
        }

        //recorrido inverso usando for
        System.out.println("***********************");
        for(int a=numeros.length-1; a>=0; a--){
            System.out.println(numeros[a]+" "+nombres[a]);
        }


        //Vector String[] args

        System.out.println("Longitud args: "+args.length);
        for(int a=0; a<args.length; a++){
            System.out.println(args[a]);
        }

        


    }
}