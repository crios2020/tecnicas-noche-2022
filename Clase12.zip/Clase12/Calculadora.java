public class Calculadora {
    public static void main(String[] args) {
        /*
            Calculadora

        Ingresan como datos por consola de sistema o consola de programa
        3 parametros numero1 - operacion('+' '-' '*' '/') - numero2
        realizar la operación matemáticas correspondiente

        int numero1=Integer.parseInt(args[0]);
        int numero2=Integer.parseInt(args[1]);
        */
    }
}
