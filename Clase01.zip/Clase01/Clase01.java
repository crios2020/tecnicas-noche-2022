/*
 * 		Curso: 	Tecnicas de Programación			120 hs
 * 		Días:	Lunes y Viernes de 19:00 a 22:30 hs
 * 		Profe:	Carlos Rios			c.rios@bue.edu.ar
 * 
 * 		Materiales de estudios:
 * 				github: 	https://github.com/crios2020/tecnicas-noche-2022
 * 
 * 				aula virtual: https://aulasvirtuales.bue.edu.ar/
 * 
 * 		Materiales Extras:
 * 				https://www.tutorialesprogramacionya.com/
 * 				https://open-bootcamp.com/
 * 
 * 		Software:
 * 					JDK (Java Development Kit - Kit de Desarrollo Java) 
 * 					https://www.oracle.com/java/technologies/downloads/#java17
 * 
 * 					IDE (	Integrated Development Enviroment - 
 * 							Entorno de Desarrollo Integrado)
 * 					Visual Studio Code
 * 					https://code.visualstudio.com/download	
 * 
 *                  https://www.winrar.es/descargas
 * 
 * 		JDK		1 descargar
 * 				2 instalar
 * 				3 reiniciar PC
 * 				4 abrir cmd
 * 				5 en cmd ejecutar: java -version
 * 
 * 		Visual Studio Code	1 descargar
 * 							2 instalar
 * 							3 abrir
 * 							4 instalar plugin Extension Pack for Java (de microsoft)
 * 		
 *      Temario de programación estructurada
 * 
 */

// Comentario de una sola linea

/* Bloque de comentarios */

//primer programa

//clase principal
public class Clase01{
    public static void main(String[] args) {
        //método main
        //main tab atajo de teclado para el método main

        //sout tab atajo de teclaco para System.out.println();

        //Hola Mundo!
        System.out.println("Hola Mundo!!");

        //Lenguaje es case sensitive
        // ; es el terminador de sentencias

        System.out.println("Hoy es Lunes!");
        System.out.println("Aprendiendo Java");

        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.println("4");
        System.out.println("Centro de Formación Profesional nro 8");

        /*
         *  Hola Mundo!!
         *  Hoy es Lunes!
         *  Aprendiendo Java
         *  1234
         *  Centro de Formación Profesional nro 8
         * 
         */




    }//end main
}//end class principal