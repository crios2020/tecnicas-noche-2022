public class Rectangulo {
    
    private int lado1;
    private int lado2;

    //método constructor
    Rectangulo(int lado1, int lado2){
        this.lado1=lado1;
        this.lado2=lado2;
    }

    double perimetro(){
        return (lado1+lado2)*2;
    }

    double superficie(){
        return lado1*lado2;
    }
}
