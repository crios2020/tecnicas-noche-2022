public class Circulo {
    private int radio;

    Circulo(int radio){
        this.radio=radio;
    }

    double perimetro(){
        return Math.PI*radio*2;
    }

    double superficie(){
        return Math.PI*radio*radio;
    }
}
