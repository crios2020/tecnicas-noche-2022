public class Clase27{
    public static void main(String[] args) {
        
        //Clase 27
        System.out.println("-- auto1 --");
        Auto auto1 = new Auto();        //se construye un objeto de la clase Auto

        auto1.marca="Fiat";
        auto1.modelo="Toro";
        auto1.color="Rojo";
        auto1.acelerar();           //10
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        auto1.frenar();             //20

        System.out.println( 
                                auto1.marca+" "+
                                auto1.modelo+" "+
                                auto1.color+" "+
                                auto1.velocidad
                        );

        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Ka";
        auto2.color="Negro";

        for(int a=0;a<=55;a++){
            auto2.acelerar();
        }

        System.out.println( 
                            auto2.marca+" "+
                            auto2.modelo+" "+
                            auto2.color+" "+
                            auto2.velocidad
                        );


        /*
                    codeshare.io/crios2020

         *          Laboratorio
         *  
         *          Crear la clase Rectangulo:
         *                  atributos: int lado1, int lado2
         *                  metodos: superficie, perimetro
         * 
         *          Crear la clase Triangulo:
         *                  atributos: int base, int altura
         *                  metodos: superficie, perimetro
         * 
         *          Crear la clase Circulo:
         *                  atributos: int radio
         *                  metodos: superficie, perimetro
         * 
         */

        System.out.println("-- rectangulo1 --");
        Rectangulo rectangulo1=new Rectangulo(20,30);
        //rectangulo1.lado1=25;
        //rectangulo1.lado2=35;
        System.out.println("Perímetro: "+rectangulo1.perimetro());
        System.out.println("Superficie: "+rectangulo1.superficie());
        
        System.out.println("-- triangulo1 --");
        Triangulo triangulo1= new Triangulo(20,30);
        System.out.println("Perímetro: "+triangulo1.perimetro());
        System.out.println("Superficie: "+triangulo1.superficie());

        System.out.println("-- circulo1 --");
        Circulo circulo1=new Circulo(15);
        System.out.println("Perímetro: "+circulo1.perimetro());
        System.out.println("Superficie: "+circulo1.superficie());

        /*
         * Agregar un constructor a la clase Auto
         */


    }
}