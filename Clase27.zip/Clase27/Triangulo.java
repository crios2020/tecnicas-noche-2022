public class Triangulo {
    
    private int base;
    private int altura;

    Triangulo(int base, int altura){
        this.base=base;
        this.altura=altura;
    }

    double perimetro(){
        return base+altura+Math.hypot(base, altura);
    }

    double superficie(){
        return base*altura/2;
    }
}
