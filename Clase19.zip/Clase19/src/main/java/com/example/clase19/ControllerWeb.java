package com.example.clase19;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControllerWeb {
    
    @GetMapping("/")
    public String getIndex(
        @RequestParam(name="nro1", defaultValue = "0", required = false) int nro1,
        @RequestParam(name="nro2", defaultValue = "0", required = false) int nro2,
        Model model){
        model.addAttribute("java", System.getProperty("java.version"));
        model.addAttribute("resultado", sumar(nro1, nro2));
        return "index";
    }

    public int sumar(int nro1, int nro2){
        return nro1+nro2;
    }
}
