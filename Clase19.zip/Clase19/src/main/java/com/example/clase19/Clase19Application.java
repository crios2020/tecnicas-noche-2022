package com.example.clase19;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase19Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase19Application.class, args);
		// sh mvnw spring-boot:run
		
	}

}
