public class Clase02 {
    public static void main(String[] args) {
        //main TAB

        //https://www.online-ide.com/

        System.out.println("Hola Mundo!!");
        System.out.println(System.getProperty("java.version"));

        //Variables en Java
        //Lenguajes de Tipado Fuerte    java - c - c++ - c# - Visual Basic - Pascal
        //Lenguajes de Tipado Debil     Python - PHP - JavaScript

        //Tipo de datos primitivos

        //Tipo de datos int
        int a;                  //declaración de variable
        a=2;                    //asignación de valor

        int b=4;                //declaración y asignación

        int c=a+b;              // 6

        int d=23, e=26, f=38, g=65; //declaración y asignación multiple

        //Una variable solo tiene una declaración,
        //pero puede tener infinitas asignaciones de valor

        //int a; //Error variable ya declarada
        a=72;
        a=45;
        a=39;
        a=8;
        a=72;

        System.out.println(a);
        System.out.println("variable a="+a);
        System.out.println("a+b="+a+b);         //a+b=24
        System.out.println("a+b="+(a+b));       //a+b=6

        //https://codeshare.io/1Y9y0m

        //Tipo de datos String
        String p="Recreo";
        String k="Cafe";
        System.out.println(p+k);
        System.out.println(p+" "+k);
        System.out.println(p+" y "+k);

        //tipo de datos char
        char car=65;
        System.out.println(car);
        
        car='C';
        System.out.println(car);

        car+=32;
        System.out.println(car);

        car=(char)a;
        System.out.println(car);

        // Tipo de datos float 32 bits
        float fl=6.25f;
        System.out.println(fl);
        
        // Tipo de datos double 64 bits
        double dl=6.25;
        System.out.println(dl);

        fl=10;
        dl=10;
        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=100;
        dl=100;
        System.out.println(fl/3);
        System.out.println(dl/3);

        //Tipo de datos boolean 
        boolean bo=true;
        System.out.println(bo);

        bo=false;
        System.out.println(bo);

        //Constantes
        //Las constantes solo pueden tener una asignación de valor en el momento de la declaraciòn
        //final double PI=3.14;
        final double PI=Math.PI;
        //PI=5; //Error no se puede cambiar de valor a una constante.
        System.out.println(PI);

        //Operador de asignación =
        int nro1=5;
        int nro2=7;
        System.out.println(nro1);
        System.out.println(nro2);

        nro1 = nro2;
        // <------

        System.out.println(nro1);
        System.out.println(nro2);

        // Operadores incrementales
        // sumar 1 a la variable    ++      (Operador Unario)
        nro1++;                     // nro1=nro1+1
        System.out.println(nro1);

        // restar 1 a la variable   --       (Operador Unario)
        nro1--;                     // nro1=nro1-1
        System.out.println(nro1);

        // sumar x a la variable    +=      (Operador Binario)
        nro1+=5;                    // nro1=nro1+5;
        System.out.println(nro1);

        // restar x a la variable   -=      (Operador Binario)
        nro1-=5;                    // nro1=nro1-5;
        System.out.println(nro1);

        // multiplicar la variable  *=      (Operador Binario)
        nro1*=5;                    // nro1=nro1*5;
        System.out.println(nro1);

        // dividir la variable      /=
        //nro1/=0;
        nro1/=5;                    //nro1=nro1/5;
        System.out.println(nro1);

        // Post Incremento para operadores unarios ++ --
        System.out.println(nro1);           // 7
        System.out.println(nro1++);         // 8
        System.out.println(nro1);

        // Pre Incremento para operadores unarios ++ --
        System.out.println(--nro1);        // 7

        // Operador Resto   %
        System.out.println(21%6);       // 3
        System.out.println(15%2);       // 1
        System.out.println(14%2);       // 0
        System.out.println(-14%2);      // 0
        System.out.println(-15%2);      //-1


        //https://desarrolloweb.com/articulos/1730.php#:~:text=Operadores%20Incrementales%3A%20Son%20los%20operadores,de%20utilizar%20o%20lo%20contrario.

        //Temas pendientes

        //Operadores Relacionales

        //Operadores Lògicos

        //Tabla de Verdad

        //Expresiones Lògicas


    }
}
