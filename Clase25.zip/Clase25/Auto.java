
//declaración de clases
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //métodos
    public void acelerar(){
        velocidad+=10;
    }

    public void frenar(){
        velocidad-=10;
    }

}//end class
