public class Clase25{
    public static void main(String[] args) {
        System.out.println("Clase 25");

        System.out.println("-- auto1 --");
        Auto auto1=new Auto();      // construye un objeto de la clase Auto
        //auto1.


    }
}