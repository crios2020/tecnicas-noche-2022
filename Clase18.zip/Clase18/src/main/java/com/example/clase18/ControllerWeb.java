package com.example.clase18;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;



@Controller
public class ControllerWeb {
    
    @GetMapping("/")
    public String index(Model model){
        model.addAttribute("java", System.getProperty("java.version"));
        return "index";
    }
}
