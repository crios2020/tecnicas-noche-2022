package com.example.clase18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase18Application {

	public static void main(String[] args) {
		// Inicia el servidor tomcat
		SpringApplication.run(Clase18Application.class, args);
		
		// como correr el server desde consola?
		// abrir consola bash - gitbash
		// sh mvnw spring-boot:run
	}

}
