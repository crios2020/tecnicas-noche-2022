package com.example.clase18;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase18ApplicationTests {

	@Test
	void contextLoads() {
	}

}
