package com.example.calculadora;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControllerWeb {
    @GetMapping("/")
    public String getMain(
        @RequestParam(name="nro1",required = false, defaultValue = "0") int nro1,
        @RequestParam(name="nro2",required = false, defaultValue = "0") int nro2,
        Model model
    ){
        model.addAttribute("resultado", sumar(nro1, nro2));
        return "index";
    }

    public int sumar(int nro1, int nro2){
        return nro1+nro2;
    }

}
