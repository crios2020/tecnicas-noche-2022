public class Rectangulo {
    public static void main(String[] args) {
        //- Crear una función llamada calcularPerimetro, deben ingresar como parámetros
        //los dos lados del rectangulo y devolver el perimetro de la figura.

        //- Crear una función llamada calcularSuperficie, deben ingresar como parámetros
        //los dos lados del rectangulo y devolver la superficie de la figura.

        int lado1=30;
        int lado2=40;

        System.out.println(calcularPerimetro(lado1, lado2));
        System.out.println(calcularSuperficie(lado1, lado2));

    }

    public static int calcularPerimetro(int lado1, int lado2){
        return (lado1+lado2)*2;
    }

    public static int calcularSuperficie(int lado1, int lado2){
        return lado1*lado2;
    }

}
