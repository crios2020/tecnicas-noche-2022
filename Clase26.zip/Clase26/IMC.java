import java.text.DecimalFormat;
import java.util.Scanner;

public class IMC {
        public static void main(String[] args) {

                /*
                 * Trabajo 2
                 * 
                 * 1 - Modificar el trabajo 1 para que permita el ingreso de parámetros por
                 * consola de sistema.
                 * 2 - Crear la función calcularMasaCorporal, en esta función ingresa como
                 * parámetro el peso y la altura,
                 * y devuelve el indice de masa corporal.
                 * 3 - Crear la función obtenerEstado, ingresa como parámetro el IMC y devuelve
                 * un String con el estado
                 * 'Normal','SobrePeso','Obesidad' etc.
                 */

                // Ingreso de parámetros por consola de sistema
                DecimalFormat df = new DecimalFormat("###.##");
                double peso;
                double altura;
                if (args.length == 2) {
                        peso = Double.parseDouble(args[0]);
                        altura = Double.parseDouble(args[1]);                     
                } else {
                        System.out.print("Ingreso el Peso: ");
                        peso = new Scanner(System.in).nextDouble();
                        System.out.print("Ingrese la Altura: ");
                        altura = new Scanner(System.in).nextDouble();
                }
                System.out.println("El valor del IMC es: " + df.format(indiceMasacorporal(peso, altura)));
                System.out.println("El estado es: "+obtenerEstado(indiceMasacorporal(peso, altura)));
        }

        public static double indiceMasacorporal(double peso, double altura) {
                return peso / (altura * altura);

        }

        public static String obtenerEstado(double imc){
                
                if (imc<16.00)                {return "Delgadez (desnutrición) severa.";}
                if (imc>=16.00 && imc<17)     {return "Delgadez (desnutrición) moderada.";}
                if (imc>=17.00 && imc<19)     {return "Delgadez (desnutrición) leve.";}
                if (imc>=18.50 && imc<25)     {return "Normal.";}
                if (imc>=25.00 && imc<30)     {return "Sobrepeso (Pre-obesidad)";}
                if (imc>=30.00 && imc<35)     {return "Obesidad Grado I (leve a moderado).";}
                if (imc>=35.00 && imc<40)     {return "Obesidad Gradoo II (severa).";}
                if (imc>=40.00)               {return "Obesidad Grado III (mórbida).";}
                return "";
        }
}