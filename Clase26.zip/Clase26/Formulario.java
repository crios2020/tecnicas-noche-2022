
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.TreeExpansionListener;

public class Formulario extends JFrame implements ActionListener {

    private JButton btnCalcular;
    JTextField txtPeso;
    JTextField txtAltura;
    JLabel lblResultado;

    //método constructor
    public Formulario(){
        this.setSize(480, 360);
        this.setTitle("Indice de Masa Corporal!");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);

        JLabel labelPeso=new JLabel();
        labelPeso.setText("Ingrese el peso (kgs): ");
        labelPeso.setBounds(10,20,200,30);
        this.add(labelPeso);

        JLabel labelAltura=new JLabel();
        labelAltura.setText("Ingrese la altura (mts): ");
        labelAltura.setBounds(10,60,200,30);
        this.add(labelAltura);
        
        txtPeso=new JTextField();
        //txtPeso.setText("");
        txtPeso.setBounds(240, 20, 200, 30);
        this.add(txtPeso);

        txtAltura=new JTextField();
        //txtAltura.setText("");
        txtAltura.setBounds(240, 60, 200, 30);
        this.add(txtAltura);

        btnCalcular=new JButton();
        btnCalcular.setText("Calcular");
        btnCalcular.setBounds(120,100,200,50);
        this.add(btnCalcular);
        btnCalcular.addActionListener(this);
        

        lblResultado=new JLabel();
        lblResultado.setText("");
        lblResultado.setBounds(10,180,420,30);
        this.add(lblResultado);

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==btnCalcular) {
            //Evento del boton calcular
            double peso=Double.parseDouble(txtPeso.getText());
            double altura=Double.parseDouble(txtAltura.getText());
            double imc=IMC.indiceMasacorporal(peso, altura);
            String estado=IMC.obtenerEstado(imc);
            lblResultado.setText("IMC: "+imc+", Estado: "+estado);
        }
    }
    
    public static void main(String[] args) {

        //Se hace visible el formulario
        new Formulario().setVisible(true);
    }
}
