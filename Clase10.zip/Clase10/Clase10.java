public class Clase10{
    public static void main(String[] args) {
        // clase10

        //Estructura While
        int x=1;
        System.out.println("-- Inicia Estructura While --");
        while(x<=10){
            System.out.println(x);
            x++;
        }
        System.out.println("-- Final Estructura While--");
        System.out.println(x);      //11
        
        //Estructura For
        System.out.println("-- Inicia Estructura For --");
        for(int a=1; a<=10; a++){

            System.out.println(a);
        }
        System.out.println("-- Final Estructura For --");
        //System.out.println(a); //Error variable destruida

        //Uso de llaves modo expandido
        for(int a=1; a<=10; a++)
        {
            System.out.println(a);
        }

        //Uso de llaves modo abreviado
        for(int a=0; a<=10; a++) System.out.println(a);

        //Recorrido con variable global
        for(x=1; x<=10; x++){
            System.out.println(x);
        }
        System.out.println(x);

        //loop infinito
        // for(int a=1; true; a++){
        //     System.out.println(a);
        // }

        //loop infinito
        // for(int a=1; a<=10 || a>=1; a++){
        //     System.out.println(a);
        // }

        // Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro.
        // Ejercicio 2
        // Imprimir los números del 1 al 10 salteando de a dos uno abajo del otro.
        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro.
        // Ejercicio 4
        // Imprimir la suma de los números impares del 1 al 10.
        // Ejercicio 5
        // Mostrar la suma de la multiplicación de los números del 1 al 5 con la suma de los números del 1 al
        // 5.
        // Ejercicio 6
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @
        // @
        // @
        // Ejercicio 7
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @
        // @@
        // @
        // Ejercicio 8
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@@@
        // Ejercicio 9
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@@
        // @@@
        // @@
        // @
        // Ejercicio 10
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@
        // @@
        // @
        // Ejercicio 11
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@
        // @
        // @@@
        // @@@@@

    }
}