public class Clase28 {
    public static void main(String[] args) {
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"args");
        cuenta1.depositar(24000);
        cuenta1.depositar(60000);
        cuenta1.debitar(50000);
        cuenta1.debitar(50000);
        System.out.println(cuenta1.getEstado());

        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(
                            1,                                  //numero
                            "Juan Perez",                       //nombre
                            new Cuenta(2,"args")        //cuenta
                            );
        
        cliente1.getCuenta().depositar(60000);
        cliente1.getCuenta().depositar(80000);
        cliente1.getCuenta().debitar(40000);
        System.out.println(cliente1.getEstado());

        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Abel","Pintos",44);
        persona1.saludar();
        persona1.caminar();
        //persona1.darPresente();
        System.out.println(persona1);

        System.out.println("-- empleado1 --");
        Empleado empleado1=new Empleado("Raul", "Palacio", 40);
        empleado1.saludar();
        empleado1.caminar();
        empleado1.darPresente();
        System.out.println(empleado1);

    }
}
