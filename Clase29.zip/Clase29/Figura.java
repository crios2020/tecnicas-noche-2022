public abstract class Figura {
    public abstract double calcularPerimetro();
    public abstract double calcularSuperficie();

    /*
     * Crear las clases hijas 
     * 
     * clase Rectangulo:    atributos int lado1,lado2
     * clase Triangulo:     atributos int base,altura
     * clase Circulo:       atributos int radio
     * 
     * sobre escribir calcularPerimetro y calcularSuperficie
     */
}
