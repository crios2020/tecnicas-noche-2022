import java.time.LocalDateTime;

public class Empleado extends Persona{

    private int nroLegajo;

    public Empleado(String nombre, String apellido, int edad) {
        super(nombre, apellido, edad);
        //super() llamar al constructor de la clase padre.
    }

    public void darPresente(){
        System.out.println(LocalDateTime.now()+" Presente!!!");
    }
    
}
