public class Clase14 {
    public static void main(String[] args) {
        //copiar vectores
        
        int[] pares={2, 4, 6, 8, 10};
        int[] impares=new int[pares.length];
        int[] pares2=new int[pares.length];

        /*
         *      pares       impares         pares2
         *          2       _1__            ___
         *          4       _3__            ___
         *          6       _5__            ___
         *          8       _7__            ___
         *         10       _9__            ___
         * 
         */
        
        //Copiar del vector pares a impares
        for(int a=0; a<pares.length; a++) impares[a]=pares[a]-1;
        for(int a=0; a<impares.length; a++) 
            System.out.println(impares[a]+" "+pares[a]);

        //Copiar del vector pares a pares2 usando System.ArrayCopy
        System.arraycopy(pares, 0, pares2, 0, pares.length);
        for(int a=0; a<pares.length; a++) System.out.println(pares[a]+" "+pares2[a]);

        //funciones
        cartel();
        cartel();
        cartel();
        cartel("*Centro de formación profesional N 8 *");
        cartel("*         Curso de Java!!            *");

        System.out.println(sumar(2,2));
        System.out.println(sumar(4,10));

        int resultado=sumar(2,2);
        System.out.println(resultado);

        //sumar(38,39);

        System.out.println(Math.PI);
        double pi=Math.PI;
        System.out.println(pi);

        cartel2();
        cartel2();


    }//end main

    private static void cartel2() {
        System.out.println("**************************************");
        System.out.println("Aprendiendo JAVA!!!!!");
        System.out.println("**************************************");
    }

    //declaración de función
    public static void cartel(){
        System.out.println("**************************************");
        System.out.println("*        HOY ES VIERNES !!!!!        *");
        System.out.println("**************************************");
    }

    //función con parámetros de ingreso
    public static void cartel(String texto){
        System.out.println("**************************************");
        System.out.println(texto);
        System.out.println("**************************************");
    }

    //Función con valor de retorno
    public static int sumar(int nro1, int nro2){
        return nro1+nro2;
    }

}//end class
