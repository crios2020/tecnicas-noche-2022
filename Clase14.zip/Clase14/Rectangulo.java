public class Rectangulo {
    public static void main(String[] args) {
        //- Crear una función llamada calcularPerimetro, deben ingresar como parámetros
        //los dos lados del rectangulo y devolver el perimetro de la figura.

        //- Crear una función llamada calcularSuperficie, deben ingresar como parámetros
        //los dos lados del rectangulo y devolver la superficie de la figura.

        
    }
}
