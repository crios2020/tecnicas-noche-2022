import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio {

    //Variables globales
    static String[] nombres=new String[100];
    static String nombre;
    static int puntero=0;
    public static void main(String[] args) {
       /*
         * - Ingresa por consola de programa o sistema una lista de nombres de 
         *   personas
         * - Informar cantidad de personas
         * - Informar la lista ordenada alfabeticamente
         * - Imprimir una persona random Math.random()
         */

        ingresarDatos(args);

        cantidadPersonas();

        ordenar();

        imprimir();


    }


    private static void ordenar() {
      //- Informar la lista ordenada alfabeticamente
      String[] nombres2=new String[puntero];
      for(int a=0;a<puntero; a++) nombres2[a]=nombres[a];
      Arrays.sort(nombres2);
      for(int a=0; a<puntero; a++) System.out.println(nombres2[a]);
    }

    private static void cantidadPersonas() {
      //- Informar cantidad de personas
      System.out.println("Se ingresaron "+puntero+" personas.");
    }

    public static void ingresarDatos(String[] args) {
      //- Ingresa por consola de programa o sistema una lista de nombres de 
      //   personas
      if(args!=null && args.length>0){
        nombres=args;
        puntero=args.length;
      } else {
        System.out.println("Ingrese nombres, cantidad máxima 100 nombres.");
        System.out.println("<ENTER> para terminar.");
        for(int a=0; a<100; a++){
          System.out.print("Ingrese un nombre: ");
          nombre=new Scanner(System.in).nextLine();
          if(nombre==null || nombre.length()==0) break;
          nombres[puntero]=nombre;
          puntero++;
        }
      }
    }

    private static void imprimir() {
      //- Imprimir una persona random Math.random()
      int random=(int)(Math.random()*puntero);
      System.out.println("Persona Random: "+nombres[random]);
    }
}
