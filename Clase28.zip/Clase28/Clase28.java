public class Clase28 {
    public static void main(String[] args) {
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"args");
        cuenta1.depositar(24000);
        cuenta1.depositar(60000);
        cuenta1.debitar(50000);
        cuenta1.debitar(50000);
        System.out.println(cuenta1.getEstado());

    }
}
