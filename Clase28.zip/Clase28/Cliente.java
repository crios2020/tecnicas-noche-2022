public class Cliente {
    private int numero;
    private String nombre;
    private Cuenta cuenta;

    public Cliente(int numero, String nombre, Cuenta cuenta){
        this.numero=numero;
        this.nombre=nombre;
        this.cuenta=cuenta;
    }

    public Cuenta getCuenta(){
        return this.cuenta;
    }

    public String getEstado(){
        return numero+" "+nombre+" "+cuenta.getEstado();
    }

}
