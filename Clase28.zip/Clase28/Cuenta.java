public class Cuenta{
    private int numero;
    private String moneda;
    private double saldo;

    public Cuenta(int numero, String moneda){
        this.numero=numero;
        this.moneda=moneda;
    }

    public void depositar(double monto){
        this.saldo+=monto;
    }

    public void debitar(double monto){
        if(saldo>=monto){
            this.saldo-=monto;
        }else{
            System.out.println("Saldo Insuficiente!");
        }
    }

    public String getEstado(){
        return numero+", "+moneda+", "+saldo;
    }

}