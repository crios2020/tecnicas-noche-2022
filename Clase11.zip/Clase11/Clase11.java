import java.text.DecimalFormat;
import java.time.LocalDateTime;

public class Clase11{
    public static void main(String[] args) {
         //utilidades de JAVA

        //Clase String
        String texto="Esto es una cadena de texto!!!";
        System.out.println(texto.toLowerCase());    //Todo Minúsculas
        System.out.println(texto.toUpperCase());    //Todo Mayúsculas
        System.out.println(texto.charAt(3)); // o
        System.out.println(texto.substring(6)); //s una cadena de texto!!!
        System.out.println(texto.substring(5,15)); //es una cad
        System.out.println(texto.startsWith("Hola"));       // false
        System.out.println(texto.startsWith("Esto"));       // true
        System.out.println(texto.endsWith("chau"));         // false
        System.out.println(texto.endsWith("!"));            // true
        System.out.println("    Hola hola    ".trim());             // Hola hola
        System.out.println(texto.contains("hola"));              // false
        System.out.println(texto.contains("texto"));             // true
        System.out.println(texto.startsWith("esto"));       // false
        System.out.println(texto.toLowerCase().startsWith("estO".toLowerCase()));  // true
        System.out.println("hola".equals("hola"));          //true
        System.out.println("Hola".equals("hola"));          //false
        System.out.println("Hola".equalsIgnoreCase("hola")); //true
        System.out.println(texto.indexOf("a"));                 //10
        
        //DecimalFormat

        // Ana,Garcia,012
        // Ana,Garcia,009

        int edad=9;
        DecimalFormat df=new DecimalFormat("000");
        System.out.println(df.format(edad));

        double precio=90000000.33333333;
        DecimalFormat df2=new DecimalFormat("###,###,###.00");
        System.out.println(df2.format(precio));

        //LocalDate - LocalTime -LocalDateTime
        LocalDateTime ldt=LocalDateTime.now();
        System.out.println(ldt.getYear());
        System.out.println(ldt.getMonth());
        System.out.println(ldt.getDayOfMonth());
        System.out.println(ldt.getDayOfWeek());
        System.out.println(ldt.getHour());
        System.out.println(ldt.getMinute());
        System.out.println(ldt.getSecond());

        //Clase Math
        System.out.println(Math.PI);
        System.out.println(Math.max(38, 39));
        System.out.println(Math.min(38, 39));
        System.out.println(Math.sqrt(16));
        System.out.println(Math.pow(4, 4));
        System.out.println(Math.round(Math.PI));
        System.out.println(Math.round(Math.random()*100));
        System.out.println(Math.hypot(40, 60));

        //Todo Arrays - Vectores
        
    }
}
