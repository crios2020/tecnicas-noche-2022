import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class EjerciciosFor{
    public static void main(String[] args) {
        
        // Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro.
        System.out.println("-- Ejercicio 1 --");
        for(int a=1; a<=10; a++) System.out.println(a);

        // Ejercicio 2
        // Imprimir los números del 1 al 10 salteando de a dos uno abajo del otro.
        System.out.println("-- Ejercicio 2 --");
        for(int a=1; a<=10; a+=2) System.out.println(a);
        
        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro.
        System.out.println("-- Ejercicio 3 --");
        for(int a=10; a>=1; a--) System.out.println(a);
        
        // Ejercicio 4
        // Imprimir la suma de los números impares del 1 al 10.
        System.out.println("-- Ejercicio 4 --");
        int total=0;
        // for(int a=1; a<=10; a++){
        //     if(a%2!=0) total+=a;
        // } 
        for(int a=1; a<=10; a+=2) total+=a;
        System.out.println("Total: "+total);
        // Ejercicio 5
        // Mostrar la suma de 
        // la multiplicación de los números del 1 al 5 
        // con 
        // la suma de los números del 1 al 5.
        System.out.println("-- Ejercicio 5 --");
        total=0;
        int multi=1;
        for(int a=1; a<=5; a++){
            multi*=a;
            total+=a;
        }
        System.out.println("Total: "+(multi+total));
        
        // Ejercicio 6
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @
        // @
        // @
        System.out.println("-- Ejercicio 6 --");
        for(int a=1; a<=5; a++) System.out.println("@");

        // Bonus
        // @@@@@
        System.out.println("-- Bonus --");
        for(int a=1; a<=5; a++) System.out.print("@");
        System.out.println();

        // Ejercicio 7
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @
        // @@
        // @
        System.out.println("-- Ejercicio 7 --");
        for(int a=1; a<=5; a++){
            if(a%2==0)  System.out.println("@@");
            else        System.out.println("@");
        }

        // Bonus
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        // @@@@@
        System.out.println("-- Bonus --");
        for(int y=1; y<=5; y++){
            for(int u=1; u<=5; u++) System.out.print("@");
            System.out.println();
        }

        // Ejercicio 8
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@@@
        System.out.println("-- Ejercicio 8 --");
        for(int y=1; y<=5; y++){
            for(int u=1; u<=y; u++) System.out.print("@");
            System.out.println();
        }
        // Ejercicio 9
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@@
        // @@@
        // @@
        // @
        System.out.println("-- Ejercicio 9 --");
        for(int y=5; y>=1; y--){
            for(int u=1; u<=y; u++) System.out.print("@");
            System.out.println();
        }

        // Ejercicio 10
        // Imprimir la siguiente figura utilizando la estructura for:
        // @
        // @@
        // @@@
        // @@@@
        // @@@@@
        // @@@@
        // @@@
        // @@
        // @
        System.out.println("-- Ejercicio 10 --");
        for(int y=1; y<=5; y++){
            for(int u=1; u<=y; u++) System.out.print("@");
            System.out.println();
        }
        for(int y=4; y>=1; y--){
            for(int u=1; u<=y; u++) System.out.print("@");
            System.out.println();
        }

        // Ejercicio 11
        // Imprimir la siguiente figura utilizando la estructura for:
        // @@@@@
        // @@@
        // @
        // @@@
        // @@@@@
        System.out.println("-- Ejercicio 11 --");
        for(int y=5; y>=1; y-=2){
            for(int u=1; u<=y; u++) System.out.print("@");
            System.out.println();
        }
        for(int y=3; y<=5; y+=2){
            for(int u=1; u<=y; u++) System.out.print("@");
            System.out.println();
        }

        //Horas minutos y segundos de un día
        //Un día tiene 24 hs
        //Una hora tiene 60 minutos
        //Un minuto tiene 60 segundos
        //Imprimir todas las horas minutos y ssegundos que hay en un día

        DecimalFormat df=new DecimalFormat("00");
        // for(int hora=0; hora<24; hora++){
        //     for(int minuto=0; minuto<60; minuto++){
        //         for(int segundo=0; segundo<60; segundo++){
        //             System.out.println( df.format(hora)+":"+
        //                                 df.format(minuto)+":"+
        //                                 df.format(segundo));
        //             try{ Thread.sleep(1000);}catch(Exception e){}
        //         }
        //     }
        // }

        // for(int hora=LocalTime.now().getHour(); hora<24; hora++){
        //     for(int minuto=LocalTime.now().getMinute(); minuto<60; minuto++){
        //         for(int segundo=LocalTime.now().getSecond(); segundo<60; segundo++){
        //             System.out.println( df.format(hora)+":"+
        //                                 df.format(minuto)+":"+
        //                                 df.format(segundo));
        //             try{ Thread.sleep(1000);}catch(Exception e){}
        //         }
        //     }
        // }

        while(true){
            System.out.println( df.format(LocalTime.now().getHour())+":"+
                    df.format(LocalTime.now().getMinute())+":"+
                    df.format(LocalTime.now().getSecond()));
            try{ Thread.sleep(1000);}catch(Exception e){}
        }


    }
}