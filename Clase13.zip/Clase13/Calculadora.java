import java.util.Scanner;

public class Calculadora {
    public static void main(String[] args) {
        /*
            Calculadora

        Ingresan como datos por consola de sistema o consola de programa
        3 parametros numero1 - operacion('+' '-' 'x' '/') - numero2
        realizar la operación matemáticas correspondiente

        */

        int numero1;
        String operador;
        int numero2;

        if(args.length==3){
            numero1=Integer.parseInt(args[0]);
            operador=args[1];
            numero2=Integer.parseInt(args[2]);
        }else{
            System.out.println("Debe Ingresar 3 argumentos (número1 - operación - número2");
            System.out.print("Ingrese el número1: ");
            numero1=new Scanner(System.in).nextInt();
            System.out.print("Ingrese la operación (+ - x /): ");
            operador=new Scanner(System.in).nextLine();
            System.out.print("Ingrese el número2: ");
            numero2=new Scanner(System.in).nextInt();
        }
        switch(operador){
            case "+": System.out.println(numero1+numero2); break;
            case "-": System.out.println(numero1-numero2); break;
            case "x": System.out.println(numero1*numero2); break;
            case "/": 
                if(numero2!=0)  System.out.println(numero1/numero2); 
                else            System.out.println("Error división /0");   
                break;
            default: System.out.println("Operación incorrecta");
        }

    }
}