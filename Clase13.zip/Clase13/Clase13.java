import java.util.Arrays;

public class Clase13 {
    public static void main(String[] args) {
        
        //declaración abreviada
        int[] vector={10,16,23,26,29,-39,38,10,12,6,65,10};

        System.out.println("Longitud vector: "+vector.length);
        for(int a=0; a<vector.length; a++) System.out.print(vector[a]+", ");
        System.out.println();

        //Totalizar un vector numérico
        //Promediar un vector numérico
        int total=0;
        for(int a=0; a<vector.length; a++){
            total+=vector[a];
        }
        System.out.println("Total: "+total);
        System.out.println("Promedio: "+((double)total/vector.length));

        //Calcular valor máximo y mínimo de un vector
        int max=vector[2];
        int min=vector[0];
        for(int a=0; a<vector.length; a++){
            if(max<vector[a]) max=vector[a];
            if(min>vector[a]) min=vector[a];
        }
        System.out.println("Valor máximo: "+max);
        System.out.println("Valor mínimo: "+min);

        //Contar cantidad de números pares
        //Contar cantidad de números impares
        //Contar cantidad de números 10

        int contPar=0;
        int contImpar=0;
        int cont10=0;
        for(int a=0; a<vector.length; a++){
            if(vector[a]%2==0)  contPar++;
            else                contImpar++;
            if(vector[a]==10)   cont10++;
        }
        System.out.println("Cantidad números pares: "+contPar);
        System.out.println("Cantidad números impares: "+contImpar);
        System.out.println("Cantidad 10: "+cont10);

        //Ordenar un vector
        Arrays.sort(vector);
        for(int a=0; a<vector.length; a++) System.out.print(vector[a]+", ");
        System.out.println();

        String[] nombres={"Victor","Beatriz","Ana","Carlos","Susana","Cristian"};
        Arrays.sort(nombres);
        for(int a=0; a<nombres.length; a++){
            System.out.println(nombres[a]);
        }

        //TODO copiar vectores
        
        //TODO funciones



    }
}
