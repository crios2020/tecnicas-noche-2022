public class Ejercicio {
    public static void main(String[] args) {
       /*
         * - Ingresa por consola de programa o sistema una lista de nombres de 
         *   personas
         * - Informar cantidad de personas
         * - Informar la lista ordenada alfabeticamente
         * - Imprimir una persona random Math.random()
         */

    }
}
