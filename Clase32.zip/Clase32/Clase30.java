public class Clase30 {
    public static void main(String[] args) {
        
        Figura figura=null;

        //Polimorfismo
        //figura=new Rectangulo(20, 20);
        //figura=new Triangulo(20, 20);
        figura=new Circulo(10);

        System.out.println("Perimetro: "+figura.calcularPerimetro());
        System.out.println("Superficie: "+figura.calcularSuperficie());


        /*
                https://codeshare.io/crios2020

         *      Vehiculo (Clase abstracta): 
         *                  atributos marca, color, velocidad
         *                  métodos concretos toString()
         *                  métodos abstractos acelerar(int kms), frenar(int kms)
         * 
         *      Clase Hija Bicicleta:   velocidad máxima 30kms
         *      Clase Hija Moto:        velocidad máxima 90kms
         *      Clase Hija Auto:        velocidad máxima 130kms
         *      Clase Hija Camion:      velocidad máxima 80kms
         * 
         */


    }
}
