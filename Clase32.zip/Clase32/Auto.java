public class Auto extends Vehiculo {

    public Auto(String marca, String color, int velocidad) {
        super(marca, color, velocidad);
    }

    @Override
    public void acelerar(int kms) {
        setVelocidad(getVelocidad()+kms);
        if(getVelocidad()>130) setVelocidad(130);
    }

    @Override
    public void frenar(int kms) {
        setVelocidad(getVelocidad()-kms);
        if(getVelocidad()<0) setVelocidad(0);
    }
}
