public class Bicicleta extends Vehiculo {

    public Bicicleta(String marca, String color, int velocidad) {
        super(marca, color, velocidad);
    }

    @Override
    public void acelerar(int kms) {
        setVelocidad(getVelocidad()+kms);
        if(getVelocidad()>30) setVelocidad(30);
    }

    @Override
    public void frenar(int kms) {
        setVelocidad(getVelocidad()-kms);
        if(getVelocidad()<0) setVelocidad(0);
    }
    
}
