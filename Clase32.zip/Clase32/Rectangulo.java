public class Rectangulo extends Figura {

    private int lado1;
    private int lado2;

    public Rectangulo(int lado1, int lado2) {
        this.lado1 = lado1;
        this.lado2 = lado2;
    }

    @Override //Anottation que indica que el método es sobreescrito
    public double calcularPerimetro() {
        return (lado1+lado2)*2;
    }

    @Override
    public double calcularSuperficie() {
        return lado1*lado2;
    }
    
}
