public class Clase32 {
    public static void main(String[] args) {
        Vehiculo vehiculo=null;

        //vehiculo=new Bicicleta("Philco", "Rojo", 0);
        vehiculo=new Moto("Yamaha","Negro",0);

        for(int a=0; a<=30; a++){
            vehiculo.acelerar(5);
            System.out.println(vehiculo);
        }


    }
}
