public class Moto extends Vehiculo{

    public Moto(String marca, String color, int velocidad) {
        super(marca, color, velocidad);
    }

    @Override
    public void acelerar(int kms) {
        setVelocidad(getVelocidad()+kms);
        if(getVelocidad()>90) setVelocidad(90);
    }

    @Override
    public void frenar(int kms) {
        setVelocidad(getVelocidad()-kms);
        if(getVelocidad()<0) setVelocidad(0);
    }
    
}
