public class Circulo extends Figura{
    private int radio;

    public Circulo(int radio) {
        this.radio = radio;
    }

    @Override
    public double calcularPerimetro() {
        return Math.PI*2*radio;
    }

    @Override
    public double calcularSuperficie() {
        return Math.PI*Math.pow(radio, 2);
    }

}
