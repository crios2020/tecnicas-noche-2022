public abstract class Vehiculo {
    private String marca;
    private String color;
    private int velocidad;

    public abstract void acelerar(int kms);
    public abstract void frenar(int kms);
    
    public Vehiculo(String marca, String color, int velocidad) {
        this.marca = marca;
        this.color = color;
        this.velocidad = velocidad;
    }
    
    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", color=" + color + ", velocidad=" + velocidad + "]";
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public int getVelocidad() {
        return velocidad;
    }
    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
   
   

}
