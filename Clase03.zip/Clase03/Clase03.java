public class Clase03{
    public static void main(String[] args) {

        //Clase03

        //Operadores Relacionales
        /*
         * Operador     Nombre
         *      <       Menor                       Binario
         *      <=      Menor Igual                 Binario
         *      >       Mayor                       Binario
         *      >=      Mayor Igual                 Binario
         *      ==      Comparación (equals)        Binario (Solo sirve para numeros o primitivos) (no compara Strings)
         *      !=      No Igual (Not Equals)       Binario
         *      !       Negación (Not)              Unario
         */

        boolean llueve=true;
        int temp=25;

        boolean log1=true;
        boolean log2=false;
        int nro1=5;
        int nro2=10;

        System.out.println(nro1<nro2);              //true
        System.out.println(nro1<=nro2);             //true
        System.out.println(nro1>nro2);              //false
        System.out.println(nro1>=nro2);             //false
        System.out.println(nro1==nro2);             //false
        System.out.println(nro1!=nro2);             //true

        System.out.println(nro1+5<nro2);            //false

        System.out.println( nro1 + 5 * 2 < nro2 * 2 + 1 );      //true

        System.out.println( ( nro1 + 5 ) * 2 < nro2 * 2 + 1 );  //true

        System.out.println( ( nro1 + 5 ) * 2 + 2 < nro2 * 2 + 1 );  

        System.out.println(log1);               //true
        System.out.println(!log1);              //false
        System.out.println(!!log1);             //true
        System.out.println(!!!log1);            //false
        System.out.println(!!!!log1);           //true

        //TODO Operadores Lògicos
        /*
         *      Operadores Logicos      Nombre
         *          &&                  AND Y
         *          ||                  OR  O
         */

        //TODO Tabla de Verdad
        /*
         *          X       Y           OR      AND
         *          F       F           F       F
         *          F       V           V       F
         *          V       F           V       F
         *          V       V           V       V
         */

         System.out.println(log1 || log2);          //true

         System.out.println(log1 && log2);          //false

         //TODO Operadores Binarios & |
        System.out.println(log1 | log2);            //true
        
        System.out.println(log1 & log2);            //false

         //TODO Expresiones Lògicas
    }
}