public class Gato {
    public static void main(String[] args) {
        System.out.println("rojo - verde - azul - negro - blanco - amarillo - purpura - cyan");
        System.out.println("Ingrese un color:");
        String color=new java.util.Scanner(System.in).nextLine();
        //System.out.println(color);

        if(color.equalsIgnoreCase("rojo"))      System.out.println(Colores.ANSI_RED);
        if(color.equalsIgnoreCase("verde"))     System.out.println(Colores.ANSI_GREEN);
        if(color.equalsIgnoreCase("azul"))      System.out.println(Colores.ANSI_BLUE);
        if(color.equalsIgnoreCase("blanco"))    System.out.println(Colores.ANSI_WHITE);
        if(color.equalsIgnoreCase("negro"))     System.out.println(Colores.ANSI_BLACK);
        if(color.equalsIgnoreCase("amarillo"))  System.out.println(Colores.ANSI_YELLOW);
        if(color.equalsIgnoreCase("purpura"))   System.out.println(Colores.ANSI_PURPLE);
        if(color.equalsIgnoreCase("cyan"))      System.out.println(Colores.ANSI_CYAN);

        /*
        //JDK 16 o sup
        System.out.println("""
            ██░▀██████████████▀░██
            █▌▒▒░████████████░▒▒▐█
            █░▒▒▒░██████████░▒▒▒░█
            ▌░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░▐
            ░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░
            ███▀▀▀██▄▒▒▒▒▒▒▒▄██▀▀▀██
            ██░░░▐█░▀█▒▒▒▒▒█▀░█▌░░░█
            ▌░░░▐▄▌░▐▌▒▒▒▐▌░▐▄▌░░▐▌
            █░░░▐█▌░░▌▒▒▒▐░░▐█▌░░█
            ▒▀▄▄▄█▄▄▄▌░▄░▐▄▄▄█▄▄▀▒
            ░░░░░░░░░░└┴┘░░░░░░░░░
            ██▄▄░░░░░░░░░░░░░░▄▄██
            ████████▒▒▒▒▒▒████████
            █▀░░███▒▒░░▒░░▒▀██████
            █▒░███▒▒╖░░╥░░╓▒▐█████
            █▒░▀▀▀░░║░░║░░║░░█████
            ██▄▄▄▄▀▀┴┴╚╧╧╝╧╧╝┴┴███
            ██████████████████████
        """);
        */
        // JDK 15 o inf
        System.out.println(
            "██░▀██████████████▀░██\n"+
            "█▌▒▒░████████████░▒▒▐█\n"+
            "█░▒▒▒░██████████░▒▒▒░█\n"+
            "▌░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░▐\n"+
            "░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░\n"+
            "███▀▀▀██▄▒▒▒▒▒▒▒▄██▀▀▀██\n"+
            "██░░░▐█░▀█▒▒▒▒▒█▀░█▌░░░█\n"+
            "▌░░░▐▄▌░▐▌▒▒▒▐▌░▐▄▌░░▐▌\n"+
            "█░░░▐█▌░░▌▒▒▒▐░░▐█▌░░█\n"+
            "▒▀▄▄▄█▄▄▄▌░▄░▐▄▄▄█▄▄▀▒\n"+
            "░░░░░░░░░░└┴┘░░░░░░░░░\n"+
            "██▄▄░░░░░░░░░░░░░░▄▄██\n"+
            "████████▒▒▒▒▒▒████████\n"+
            "█▀░░███▒▒░░▒░░▒▀██████\n"+
            "█▒░███▒▒╖░░╥░░╓▒▐█████\n"+
            "█▒░▀▀▀░░║░░║░░║░░█████\n"+
            "██▄▄▄▄▀▀┴┴╚╧╧╝╧╧╝┴┴███\n"+
            "██████████████████████"
        );

        JavaVersion.main(null);
        Ahora.main(null);

        System.out.println(Colores.ANSI_RESET);
    }
}
