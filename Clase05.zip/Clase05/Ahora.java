import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class Ahora {
    public static void main(String[] args) {

        //Utilidad Date         JDK 1.0
        //java.util.Date date=new java.util.Date();
        //Date date=new Date();
        //System.out.println(date);

        //Utilidad Calendar     JDK 1.1
        //Calendar cal=Calendar.getInstance();
        //System.out.println(cal);
        //System.out.println(cal.getTime());

        //Utilidad LocalDateTime LocalDate LocalTime        JDK 8
        LocalDateTime ldt=LocalDateTime.now();
        //System.out.println(ldt);

        int anio=ldt.getYear();
        int mes=ldt.getMonth().getValue();
        int dia=ldt.getDayOfMonth();
        int hora=ldt.getHour();
        int minuto=ldt.getMinute();
        int diaSem=ldt.getDayOfWeek().getValue();

        System.out.println(anio);
        System.out.println(mes);
        System.out.println(dia);
        System.out.println(hora);
        System.out.println(minuto);
        System.out.println(diaSem);


    }
}
