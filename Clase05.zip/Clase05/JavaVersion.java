
public class JavaVersion {
    public static void main(String[] args) {
        System.out.println(Colores.ANSI_RED);
        System.out.println("Sistema Operativo: "+
                System.getProperty("os.name")+" "+
                System.getProperty("os.version")+" "+
                System.getProperty("os.arch"));
        System.out.println("Versión Java: "+
                System.getProperty("java.vm.name")+" "+
                System.getProperty("java.version"));
        System.out.println(Colores.ANSI_RESET);
        
    }
}
