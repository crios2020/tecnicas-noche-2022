public class Clase09{
    public static void main(String[] args) {
        //Estructura while
        int i=1;
        System.out.println("************************");
        while(i<=10){
            System.out.println(i);
            i++;
        }
        System.out.println("************************");
        System.out.println(i);      //11
        System.out.println(System.getProperty("java.version"));

        //Modo de uso de llaves expandido 
        i=1;
        while(i<=10)
        {
            System.out.println(i);
            i++;
        }

        //Modo de uso de llaves abreviado
        i=1;
        while(i<=10) System.out.println(i++);

        //loop infinito
        // i=1;
        // while(true){
        //     System.out.println(i);
        //     i++;
        // }

        //loop infinito
        // i=1;
        // while(i<=10 || true){
        //     System.out.println(i);
        //     i++;
        // }

        //loop infinito
        // i=1;
        // while(i<=10 || i>1){
        //     System.out.println(i);
        //     i++;
        // }

        //loop infinito
        // i=1;
        // while(i<=10){
        //     System.out.println(i--);
        //     i++;
        // }

        //loop infinito
        // i=1;
        // while(i<=10);
        // {
        //     System.out.println(i);
        //     i++;
        // }   
        
        
    }
}