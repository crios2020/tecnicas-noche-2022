public class PracticaWhile {
    public static void main(String[] args) {
        // Laboratorio While
        // Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro.
        System.out.println("-- Ejercicio 1 --");
        int a=1;
        while(a<=10){
            System.out.println(a);
            a++;
        }
        // Ejercicio 2
        // Imprimir los números del 1 al 10 salteando de a 2 uno abajo del otro.
        System.out.println("-- Ejercicio 2 --");
        a=1;
        while(a<=10){
            System.out.println(a);
            a+=2;
        }
        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro.
        System.out.println("-- Ejercicio 3 --");
        a=10;
        while(a>=1){
            System.out.println(a);
            a--;
        }
        // Ejercicio 4
        // Imprimir los números del 1 al 10 sin imprimir números 2,5 y 9 uno abajo del otro
        // Requisito: se necesita tener conocimiento del operador AND (&&) y del operador NOT (!=).
        System.out.println("-- Ejercicio 4 --");
        a=1;
        while(a<=10){
            if(a!=2 && a!=5 && a!=9) System.out.println(a);
            a++;
        }
        // Ejercicio 5
        // Imprimir los números del 1 al 30 sin imprimir números entre el 10 y el 20 uno abajo del otro
        // Requisito: se necesita tener conocimientos del operador OR (||).
        System.out.println("-- Ejercicio 5 --");
        a=1;
        while(a<=30){
            if(a<10 || a>20) System.out.println(a);
            a++;
        }
        // Ejercicio 6
        // Imprimir la suma de los números del 1 al 10.
        System.out.println("-- Ejercicio 6 --");
        System.out.println(1+2+3+4+5+6+7+8+9+10);
        int suma=0;
        a=1;
        while(a<=10){
            suma+=a;
            a++;
        }
        System.out.println("Total: "+suma);
        // Ejercicio 7
        // Imprimir la suma de los números pares del 1 al 25
        // Requisito: se necesita tener conocimientos del operador RESTO (%).
        System.out.println("-- Ejercicio 7 --");
        suma=0;
        a=1;
        while(a<=25){
            if(a%2==0) suma+=a;
            a++;
        }
        System.out.println("Total: "+suma);

        // Ejercicio 8
        // Imprimir la multiplicación de los números impares 
        // que se encuentran entre -10 y 10.
        System.out.println("-- Ejercicio 8 --");
        int multi=1;
        a=-10;
        while(a<=10){
            if(a%2!=0) multi*=a;
            a++;
        }
        System.out.println("Total: "+multi);

    }
}
