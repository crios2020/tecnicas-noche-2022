import java.time.LocalDateTime;
import java.util.Calendar;
//import java.util.Date;

public class Ahora {
    public static void main(String[] args) {

        //Utilidad Date         JDK 1.0
        //java.util.Date date=new java.util.Date();
        //Date date=new Date();
        //System.out.println(date);

        //Utilidad Calendar     JDK 1.1
        Calendar cal=Calendar.getInstance();
        //System.out.println(cal);
        //System.out.println(cal.getTime());

        //Utilidad LocalDateTime LocalDate LocalTime        JDK 8
        LocalDateTime ldt=LocalDateTime.now();
        //System.out.println(ldt);

        String zona=cal.getTimeZone().getID();
        int anio=ldt.getYear();
        int mes=ldt.getMonth().getValue();
        int dia=ldt.getDayOfMonth();
        int hora=ldt.getHour();
        int minuto=ldt.getMinute();
        int diaSem=ldt.getDayOfWeek().getValue();

        //System.out.println(anio);
        //System.out.println(mes);
        //System.out.println(dia);
        //System.out.println(hora);
        //System.out.println(minuto);
        //System.out.println(diaSem);

        String nombreMes="";
        /*
        if(mes==1)  nombreMes="Enero";
        if(mes==2)  nombreMes="Febrero";
        if(mes==3)  nombreMes="Marzo";
        if(mes==4)  nombreMes="Abril";
        if(mes==5)  nombreMes="Mayo";
        if(mes==6)  nombreMes="Junio";
        if(mes==7)  nombreMes="Julio";
        if(mes==8)  nombreMes="Agosto";
        if(mes==9)  nombreMes="Septiembre";
        if(mes==10) nombreMes="Octubre";
        if(mes==11) nombreMes="Noviembre";
        if(mes==12) nombreMes="Diciembre";
        */
        switch(mes){
            case 1:     nombreMes="Enero";      break;
            case 2:     nombreMes="Febrero";    break;
            case 3:     nombreMes="Marzo";      break;
            case 4:     nombreMes="Abril";      break;
            case 5:     nombreMes="Mayo";       break;
            case 6:     nombreMes="Junio";      break;
            case 7:     nombreMes="Julio";      break;
            case 8:     nombreMes="Agosto";     break;
            case 9:     nombreMes="Septiembre"; break;
            case 10:    nombreMes="Octubre";    break;
            case 11:    nombreMes="Noviembre";  break;
            case 12:    nombreMes="Diciembre";  break;
        }
        
        String nombreDia="";
        /*
        if(diaSem==1)   nombreDia="Lunes"; 
        if(diaSem==2)   nombreDia="Martes"; 
        if(diaSem==3)   nombreDia="Miércoles"; 
        if(diaSem==4)   nombreDia="Jueves"; 
        if(diaSem==5)   nombreDia="Viernes"; 
        if(diaSem==6)   nombreDia="Sábado"; 
        if(diaSem==7)   nombreDia="Domingo"; 
        */
        switch(diaSem){
            case 1:     nombreDia="Lunes";      break;
            case 2:     nombreDia="Martes";     break;
            case 3:     nombreDia="Miércoles";  break;
            case 4:     nombreDia="Jueves";     break;
            case 5:     nombreDia="Viernes";    break;
            case 6:     nombreDia="Sábado";     break;
            case 7:     nombreDia="Domingo";    break;
        }

        System.out.println(Colores.ANSI_BLUE);
        System.out.println(zona);
        System.out.println("Hoy es "+nombreDia+" "+dia+" de "+nombreMes
            +" de "+anio+" hora: "+hora+":"+minuto);
        System.out.println(Colores.ANSI_RESET);
        

    }
}
