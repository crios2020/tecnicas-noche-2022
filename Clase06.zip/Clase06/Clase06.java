public class Clase06 {
    public static void main(String[] args) {
        //Estructura Switch case
        //https://codeshare.io/pqEpm4

        int temp=2;

        if(temp<15){
            System.out.println("Usar Abrigo");
        }else{
            System.out.println("No usar Abrigo");
        }

        if(temp<25) System.out.println("Remera");
        if(temp<20) System.out.println("Buzo");
        if(temp<15) System.out.println("Campera");
        if(temp<10) System.out.println("Bufanda");
        if(temp<5)  System.out.println("Guantes");
        if(temp<0)  System.out.println("Gorro Polar");

        int dia=1;
        switch(dia){
            case 1: System.out.println("Lunes");    break;
            case 2: System.out.println("Martes");   break;
            case 3: System.out.println("Miércoles");break;
            case 4: System.out.println("Jueves");   break;
            case 5: System.out.println("Viernes");  break;
            case 6: System.out.println("Sábado");   break;
            case 7: System.out.println("Domingo");  break;
            default: System.out.println("Error!");
        }
        dia=3;
        switch(dia){
            case 1: 
                System.out.println("Lunes");    
                System.out.println("Día Laboral");
                break;
            case 2: 
                System.out.println("Martes");   
                System.out.println("Día Laboral");
                break;
            case 3: 
                System.out.println("Miércoles");
                System.out.println("Día Laboral");
                break;
            case 4: 
                System.out.println("Jueves");   
                System.out.println("Día Laboral");
                break;
            case 5: 
                System.out.println("Viernes");  
                System.out.println("Día Laboral");
                break;
            case 6: 
                System.out.println("Sábado");   
                System.out.println("Feriado");
                break;
            case 7: 
                System.out.println("Domingo");  
                System.out.println("Feriado");
                break;
            default: System.out.println("Error!");
        }

        dia=2;
        switch(dia){
            case 1: case 2: case 3: case 4: case 5:
                System.out.println("Día Laboral");      break;     
            case 6: case 7:
                System.out.println("Fin de semana");    break; 
            default: System.out.println("Error!");
        }

        dia=4;
        switch(dia){
            case 1: System.out.println("Lunes");    
            case 2: System.out.println("Martes");   
            case 3: System.out.println("Miércoles");
            case 4: System.out.println("Jueves");   
            case 5: System.out.println("Viernes");  
            case 6: System.out.println("Sábado");   
            case 7: System.out.println("Domingo");  break;
            default: System.out.println("Error!");
        }

    }
}
