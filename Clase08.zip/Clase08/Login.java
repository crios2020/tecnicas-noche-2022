import java.util.Scanner;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class Login {
    
    public static void main(String[] args) {
        System.out.println(Colores.ANSI_GREEN);
        System.out.println("****************************************");
        System.out.println("*          Ingreso al Sistema          *");
        System.out.println("****************************************");
        System.out.println();
        System.out.print("Ingrese su nombre de Usuario: ");
        String usuario=new Scanner(System.in).nextLine();
        System.out.print("Ingrese su clave: ");
        String clave=new Scanner(System.in).nextLine();

        // if(usuario.equals("root")){
        //     if(clave.equals("123")){
        //         System.out.println(Colores.ANSI_BLUE+"Bienvenido al sistema!");
        //     }else{
        //         System.out.println(Colores.ANSI_RED+"Clave Incorrecta!");
        //     }
        // }else{
        //     System.out.println(Colores.ANSI_RED+"Usuario Incorrecto!");
        // }
    
        if(usuario.equals("root") && clave.equals("123")) 
            System.out.println(Colores.ANSI_BLUE+"Bienvenido al sistema!");
        if(usuario.equals("root") && !clave.equals("123"))  
            System.out.println(Colores.ANSI_RED+"Clave Incorrecta!");  
        if(!usuario.equals("root")) 
            System.out.println(Colores.ANSI_RED+"Usuario Incorrecto!");
        
        System.out.println(Colores.ANSI_RESET);
    }
}
