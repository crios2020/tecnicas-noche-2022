import java.util.Scanner;

public class Rectangulo{
    public static void main(String[] args) {
        System.out.println("Ingresar longitud de Lado1:");
        int lado1=new Scanner(System.in).nextInt();
        System.out.println("Ingresar longitud de Lado2:");
        int lado2=new Scanner(System.in).nextInt();
        int superficie=lado1*lado2;
        int perimetro=(lado1+lado2)*2;
        System.out.println("Superficie: "+superficie);
        System.out.println("Perímetro: "+perimetro);
        
    }
}