import java.util.Scanner;

public class Ejercicio4 {
    public static void main(String[] args) {
        //https://codeshare.io/tecnicasCentro8
        // Laboratorio 4 Estructura IF

        //Ejercicio 1
        //Dado el siguiente código:
        //int nro1 = 100, nro2 = 500, nro3 = 250;
        // Informar cuál de los tres números es mayor.
        // System.out.println("-- Ejercicio 1 --");
        // System.out.print("Ingrese el nro1: ");
        // int nro1=new java.util.Scanner(System.in).nextInt();
        // System.out.print("Ingrese el nro2: ");
        // int nro2=new java.util.Scanner(System.in).nextInt();
        // System.out.print("Ingrese el nro3: ");
        // int nro3=new java.util.Scanner(System.in).nextInt();

        // if(nro1>nro2){
        //     if(nro1>nro3){
        //         System.out.println("nro1 es el mayor!");
        //     }else{
        //         System.out.println("nro3 es el mayor!");
        //     }
        // }else{
        //     if(nro2>nro3){
        //         System.out.println("nro2 es el mayor1");
        //     }else{
        //         System.out.println("nro3 es el mayor!");
        //     }
        // }
        
        // if(nro1>=nro2 && nro1>=nro3) System.out.println("nro1 es el mayor!");
        // if(nro2>=nro1 && nro2>=nro3) System.out.println("nro2 es el mayor1");
        // if(nro3>=nro1 && nro3>=nro2) System.out.println("nro3 es el mayor!");

        //Ejercicio 2
        //A partir del siguiente código:
        int a = 10, b=2, c=-5;
        //hay 2 números positivos y 1 negativo Informar la multiplicación de los 
        //dos números positivos.
        // System.out.println("-- Ejercicio 2 --");
        // if(a<0) System.out.println(b*c);
        // if(b<0) System.out.println(a*c);
        // if(c<0) System.out.println(a*b);

        //Ejercicio 3
        //Tomando el siguiente código:
        //String usuario = “Pepito”, clave= “1234”;
        //Informar los siguientes casos:
        //1. Si el usuario es ”pepito” y la clave es ”1234” informar “¡Bienvenido pepito!”.
        //2. Si el usuario es ”pepito” y la clave no es “1234” informar “Contraseña incorrecta”.
        // System.out.println("-- Ejercicio 3 --");
        // System.out.print("Ingrese su nombre de usuario: ");
        // String usuario=new java.util.Scanner(System.in).nextLine();
        // System.out.println("Ingrese su clave: ");
        // String clave=new java.util.Scanner(System.in).nextLine();
        // if(usuario.equals("pepito") && clave.equals("1234")) 
        //     System.out.println("¡Bienvenido pepito!");
        // if(usuario.equals("pepito") && !clave.equals("1234")) 
        //     System.out.println("Contraseña incorrecta");
        // if(!usuario.equals("pepito"))
        //     System.out.println("Usuario Incorrecto");


        //Ejercicio 4
        //Ingresa por consola dos numeros y un string con el nombre de 
        //operación, La operación puede ser (suma - resta - multiplicación
        // - división)
        // informar el resultado de la operación matematicas.
        System.out.println("-- Ejercicio 4 --");
        System.out.print("Ingrese el número 1: ");
        int nro1=new Scanner(System.in).nextInt();
        System.out.print("Ingrese el número 2: ");
        int nro2=new Scanner(System.in).nextInt();
        System.out.print("Ingrese una operación ('+', '-', '/', '*'): ");
        String operacion=new Scanner(System.in).nextLine();

        switch (operacion){
            case "+": case "sumar":
                System.out.println("Resultado: "+(nro1+nro2)); break;
            case "-": case "restar":
                System.out.println("Resultado: "+(nro1-nro2)); break;
            case "*": case "multiplicar":
                System.out.println("Resultado: "+(nro1*nro2)); break;
            case "/": case "dividir":
                if(nro2!=0){
                    System.out.println("Resultado: "+(nro1/nro2));
                }else{
                    System.out.println("Error división por cero!");
                }
                break;
            default: System.out.println("Error - Operación no encontrada!");
        }

        //TODO TP Entregable
            
    }
}
