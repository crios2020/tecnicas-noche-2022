import java.text.DecimalFormat;
import java.util.Scanner;

public class Circulo {
    public static void main(String[] args) {
        System.out.println("Ingresar longitud del radio: ");
        double radio=new Scanner(System.in).nextDouble();
        double perimetro=radio*2*Math.PI;
        double superficie=Math.PI*Math.pow(radio, 2);
        System.out.println("Superficie: "
                +new DecimalFormat("###,###.00").format(superficie));
        System.out.println("Perimetro: "
                +new DecimalFormat("###,###.00").format(perimetro));

    }
}
